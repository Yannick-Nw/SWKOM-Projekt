# SWKOM-Projekt
https://github.com/Yannick-Nw/SWKOM-Projekt.git
