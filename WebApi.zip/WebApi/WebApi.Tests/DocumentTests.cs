using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using System.Net;
using WebApi.Endpoints;

namespace WebApi.Tests;

/// <summary>
/// Test the documents endpoint
/// </summary>
public class DocumentTests
{
    [Fact]
    public void Test1()
    {
        //// Arrange
        //var dbContext = new Mock

        //DocumentEndpoints.GetDocumentAsync()

        //// Act
        //var response = await _client.GetAsync("/");
        //response.EnsureSuccessStatusCode();
        //var responseString = await response.Content.ReadAsStringAsync();

        //// Assert
        //Assert.Equal("Hello World!", responseString);
    }
}