﻿using AutoMapper;

namespace WebApi.Mappings;

public class PaperlessProfile : Profile
{
    public PaperlessProfile()
    {

    }
}
